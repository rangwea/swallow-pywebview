---
title: "Jane-Theme Footnote Preview"
date: 2018-03-01T16:01:23+08:00
lastmod: 2018-03-01T16:01:23+08:00
draft: false
tags: ["footnote", "markdown", "tag-11"]
categories: ["docs", "index"]
author: "xianmin"
---

Hugo-theme-jane optimized for footnote. When you mouse hover the footnote[^example] , footnote content will be displayed.

[^example]: example footnote show.

<!--more-->

## Footnote-1

``` markdown
You can create footnotes like this[^footnote].

[^footnote]: Here is the *text* of the **footnote**.
```

will produce:

You can create footnotes like this[^footnote1].

[^footnote1]: Here is the *text* of the **footnote-1**.

Mouse on the ‘footnote’ superscript to see content of the footnote.

## Footnote-2

``` markdown
You can create footnotes like this[^footnote2].

[^footnote2]: Here is the *text* of the **footnote**.
```

will produce:

You can create footnotes like this[^footnote].

[^footnote]: Here is the *text* of the **footnote-2**. Here is the text of the footnote-2. Here is the text of the footnote-2. Here is the text of the footnote-2. Here is the text of the footnote-2.  [The world’s fastest framework for building websites | Hugo](https://gohugo.io/)

Mouse on the ‘footnote’ superscript to see content of the footnote.

## Footnote-3

``` markdown
You can create footnotes like this[^footnote].

[^footnote]: Here is the *text* of the **footnote**.
```

will produce:

You can create footnotes like this[^footnote3].

[^footnote3]: Here is the *text* of the **footnote-3**.

Mouse on the ‘footnote’ superscript to see content of the footnote.

## Footnote-4

``` markdown
You can create footnotes like this[^footnote].

[^footnote]: Here is the *text* of the **footnote**.
```

will produce:

You can create footnotes like this[^footnote4].

[^footnote4]: Here is the *text* of the **footnote-4**.

Mouse on the ‘footnote’ superscript to see content of the footnote.

## Footnote-5

``` markdown
You can create footnotes like this[^footnote].

[^footnote]: Here is the *text* of the **footnote**.
```

will produce dddddddddddddddddddddddddddddddddddddddddddddd:

You can create footnotes like this[^footnote5].

[^footnote5]: Here is the *text* of the **footnote-5**.

Mouse on the ‘footnote’ superscript to see content of the footnote.
